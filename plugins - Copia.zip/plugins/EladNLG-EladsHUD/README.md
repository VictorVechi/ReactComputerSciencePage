# Elad's HUD

Replaces your health stamina and battery with better UI. 

Objectively.

## SCREENSHOTS!!!

![screen shot 1](https://raw.githubusercontent.com/EladNLG/EladsHUD/main/assets/screenshot1.png)
![screen shot 2](https://raw.githubusercontent.com/EladNLG/EladsHUD/main/assets/screenshot2.png)

# Patch Notes

## 1.3

- Fixed most of the aliasing whilst using this HUD.
- Fixed planetary info not showing up. For the REAL eladshud fans, this is toggleable in the config.
- The unity project is now open-source.
- Added a border around the healthbar.

## 1.2

- no longer overloaded with information
- config!!!
  - so many options much wow!
  - use r2modman's config editor so you dont suffer lmao

## 1.1

- Added a separate element for unequipped, active flashlights.
- Layout adjustments.
- The stamina bar now turns red when you are unable to initiate a sprint.
- Healthbar now disappears automatically for added immersion.

A note that the Push-to-talk element may be obscured, as the UI was not designed with it in mind. May fix later.