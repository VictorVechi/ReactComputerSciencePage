# MirageCore

A set of dependencies for Mirage.

This currently contains the following binaries:
- [FSharp.Core](https://fsharp.org/) - 8.0
- [FSharp.Control.AsyncSeq](https://fsprojects.github.io/FSharp.Control.AsyncSeq/) - 3.2.1
- [FSharpPlus](https://github.com/fsprojects/FSharpPlus) - 1.5.0
- [FSharpx.Async](https://github.com/fsprojects/FSharpx.Async) - 1.13.2

Icon created by [IntegrityFate](https://integrityfate.com/).