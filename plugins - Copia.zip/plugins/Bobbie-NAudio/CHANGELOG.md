# 2.2.2
+ Fixed NAudio.dll targeting a .NET version that broke some projects

